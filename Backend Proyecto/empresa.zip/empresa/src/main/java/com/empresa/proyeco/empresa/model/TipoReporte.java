package com.empresa.proyeco.empresa.model;

public enum TipoReporte {
    DEMANDA,
    RUTAS
    
}
